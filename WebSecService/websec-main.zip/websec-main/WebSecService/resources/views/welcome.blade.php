@extends('layouts.master')
@section('title', 'Welcome')
@section('content')
    <div class="card m-4">
      <div class="card-body" style="color:red;font-weight: bolder;">
        Welcome to Home Page (Final Exam Version - Spring 2025) - Version 1.01
      </div>
    </div>
@endsection
